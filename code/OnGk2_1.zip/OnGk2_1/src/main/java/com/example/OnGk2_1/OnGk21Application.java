package com.example.OnGk2_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnGk21Application {

	public static void main(String[] args) {
		SpringApplication.run(OnGk21Application.class, args);
	}

}
