package com.example.OnGk2_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnGk21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
